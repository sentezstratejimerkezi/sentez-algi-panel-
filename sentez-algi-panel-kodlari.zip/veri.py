# Veri işleme modülü
