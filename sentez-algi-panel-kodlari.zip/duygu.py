# Duygu analizi modülü
