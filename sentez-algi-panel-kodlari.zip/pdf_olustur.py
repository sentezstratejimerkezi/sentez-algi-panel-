# PDF oluşturma fonksiyonları
