# Streamlit app.py örnek kodu
import streamlit as st
st.title('Sentez Algı Paneli')