# Sentez Algı Paneli
Bu proje, ilçelere göre sosyal medya algısını analiz eder.